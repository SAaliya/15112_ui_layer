$(document).ready(function () {
    $("form").submit(function (event) {
        // console.log($("#firstName").val());
        let test = false;
        if ($("firstName").val().length >= 2) { 
            alert(this.val());
            return;
        }else {
            event.preventDefault();//stops the default behavior
            }
        if ($("lastName").val().length >= 2) { 
            return ;
        } else {
            event.preventDefault();//stops the default behavior
            }

    });
});

//incase of $("form").submit()
//it submits the data to server 
//calling event.preventDefault() indicates we want to stop the
//default behavior
//as we want to send the request to server only if 
//the form has valid data